package com.iexpertapp.supelotweb;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "TagError";
    private String mCM;
    private ValueCallback<Uri> mUM;
    private ValueCallback<Uri[]> mUMA;
    private final static int FCR=1;
    public String url;
    WebView webView;
    ProgressBar progressBar;
    Context context;
    Activity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = MainActivity.this;
        activity = this;




        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);

        url = getString(R.string.website_link);

        LoadUrl();





    }


    private void LoadUrl() {

        assert webView != null;
        WebSettings webSettings = webView.getSettings();
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setLoadsImagesAutomatically(true);

        if(Build.VERSION.SDK_INT >= 21){
            webView.getSettings().setMixedContentMode(0);
            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }else if(Build.VERSION.SDK_INT >= 19){
            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }else if(Build.VERSION.SDK_INT < 19){
            webView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        webView.setWebViewClient(new Callback());
        webView.loadUrl(url);
        webView.setWebChromeClient(new WebChromeClient(){
            @Override
            public void onProgressChanged(WebView view, int progress) {
                super.onProgressChanged(view, progress);
                progressBar.setVisibility(View.VISIBLE);
                progressBar.setProgress(progress);

                // Return the app name after finish loading
                if(progress == 100) {
                    progressBar.setVisibility(View.GONE);
                 /*   AdmobInterstitialApplicator.getInstance().showInterstitial(activity, ()->{});
                    AdmobInterstitialApplicator.getInstance().initAds(activity);*/
                }

            }

            //For Android 3.0+
            public void openFileChooser(ValueCallback<Uri> uploadMsg){
                mUM = uploadMsg;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(Intent.createChooser(i,"File Chooser"), FCR);
            }
            // For Android 3.0+, above method not supported in some android 3+ versions, in such case we use this
            public void openFileChooser(ValueCallback uploadMsg, String acceptType){
                mUM = uploadMsg;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(
                        Intent.createChooser(i, "File Browser"),
                        FCR);
            }
            //For Android 4.1+
            public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture){
                mUM = uploadMsg;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(Intent.createChooser(i, "File Chooser"), FCR);
            }
            //For Android 5.0+
            // For Android 5.0+
            public boolean onShowFileChooser(
                    WebView webView, ValueCallback<Uri[]> filePathCallback,
                    WebChromeClient.FileChooserParams fileChooserParams) {
                if (mUMA != null) {
                    mUMA.onReceiveValue(null);
                }
                mUMA = filePathCallback;

                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    File photoFile = null;
                    try {
                        photoFile = createImageFile();
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photoFile));
                    } catch (IOException ex) {
                        Log.e(TAG, "Image file creation failed", ex);
                        Toast.makeText(context, "Error: " + ex.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                    if (photoFile != null) {
                        mCM = photoFile.getAbsolutePath();
                    } else {
                        takePictureIntent = null;
                    }
                }

                Intent contentSelectionIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
                contentSelectionIntent.setType("*/*");

                Intent[] intentArray;
                if (takePictureIntent != null) {
                    intentArray = new Intent[]{takePictureIntent};
                } else {
                    intentArray = new Intent[0];
                }

                Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
                chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
                chooserIntent.putExtra(Intent.EXTRA_TITLE, "Image Chooser");
                chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray);

                startActivityForResult(chooserIntent, FCR);
                return true;
            }

        });


        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {

                String fileName = null;
                // Extract the filename from the content disposition header
                String destinationDirectory=null;
                // Set the destination path with the desired filename
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    if (contentDisposition != null && !contentDisposition.isEmpty()) {
                        String[] elements = contentDisposition.split(";");
                        for (String element : elements) {
                            if (element.trim().startsWith("filename")) {
                                String[] namePair = element.split("=");
                                if (namePair.length == 2) {
                                    fileName = namePair[1].trim().replaceAll("\"", "");
                                }
                                break;
                            }
                        }
                    }

                    // If filename extraction fails, fallback to default naming based on file extension
                    if (fileName == null) {
                        String fileExtension = MimeTypeMap.getFileExtensionFromUrl(url);
                        if (fileExtension != null) {
                            fileName = "file_" + System.currentTimeMillis() + "." + fileExtension;
                        } else {
                            fileName = "file_" + System.currentTimeMillis();
                        }
                    }

                    // Set the destination directory based on the file extension
                    String fileExtension = MimeTypeMap.getFileExtensionFromUrl(fileName);



                    if (fileExtension != null && (fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("jpg"))) {
                        destinationDirectory = Environment.DIRECTORY_DOWNLOADS;
                    } else if (fileExtension != null && fileExtension.equalsIgnoreCase("pdf")) {
                        destinationDirectory = Environment.DIRECTORY_DOWNLOADS;
                    } else {
                        destinationDirectory = Environment.DIRECTORY_DOWNLOADS;
                    }

                    request.setDestinationInExternalPublicDir(destinationDirectory, fileName);


                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);


                    DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    if (downloadManager != null) {
                        long downloadId = downloadManager.enqueue(request);
                        registerDownloadCompleteReceiver(downloadId, fileName, destinationDirectory);
                    }

                } else {




                    // Request storage permission using Dexter
                    Dexter.withActivity((Activity) context)
                            .withPermissions(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            .withListener(new MultiplePermissionsListener() {
                                @Override
                                public void onPermissionsChecked(MultiplePermissionsReport report) {
                                    if (report.areAllPermissionsGranted()) {


                                        // Get the file name from the content disposition
                                        String fileName2 = URLUtil.guessFileName(url, contentDisposition, mimeType);


                                        // Create a DownloadManager request
                                        DownloadManager.Request request2 = new DownloadManager.Request(Uri.parse(url));
                                        request2.setMimeType(mimeType);
                                        request2.addRequestHeader("User-Agent", userAgent);
                                        request2.setDescription("Downloading file");
                                        request2.setTitle(fileName2);

                                        // Set cookies if needed
                                        String cookies = CookieManager.getInstance().getCookie(url);
                                        if (cookies != null) {
                                            request2.addRequestHeader("Cookie", cookies);
                                        }

                                        // Set the destination path for the downloaded file
                                        request2.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName2);

                                        // Set notification visibility to remain visible after download completion
                                        request2.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

                                        // Enqueue the download
                                        DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                                        if (downloadManager != null) {
                                            downloadManager.enqueue(request2);
                                        }


                                    }
                                }

                                @Override
                                public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                                    // Handle permission rationale if needed
                                    token.continuePermissionRequest();
                                }
                            })
                            .check();



                }

                // Add other desired download settings if needed

            }
        });




        webView.setWebViewClient(new WebViewClient(){

            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Handle all URLs
                view.loadUrl(url);
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // For Android Nougat (API level 24) and above
                Uri url = request.getUrl();
                view.loadUrl(url.toString());
                return true;
            }


        }); // this line force the link to open in webView

        webView.getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
            @Override
            public void onScrollChanged() {

            }
        });

        webView.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    WebView webView = (WebView) v;

                    switch(keyCode) {
                        case KeyEvent.KEYCODE_BACK:
                            if (webView.canGoBack()) {
                                webView.goBack();
                                return true;
                            }
                            break;
                    }
                }

                return false;
            }
        });



    }

    private void registerDownloadCompleteReceiver(final long downloadId, final String fileName, final String destinationDirectory) {
        BroadcastReceiver onComplete = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaScannerConnection.scanFile(context, new String[]{destinationDirectory + "/" + fileName}, null, null);
                } else {
                    String filePath = Environment.getExternalStorageDirectory().toString() + "/" + destinationDirectory + "/" + fileName;
                    context.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse("file://" + filePath)));
                }
                context.unregisterReceiver(this);
            }
        };
        registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
    }


    public class Callback extends WebViewClient{
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl){
            Toast.makeText(context, "Failed loading app!", Toast.LENGTH_SHORT).show();
        }
    }
    // Create an image file
    private File createImageFile() throws IOException {
        @SuppressLint("SimpleDateFormat") String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "img_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        // File imageFile = File.createTempFile(imageFileName, ".jpg", storageDir);

        File image = new File(storageDir.toString()+"/"+imageFileName+".jpg");

        // Update the file URI using FileProvider
        Uri imageUri = FileProvider.getUriForFile(context, getPackageName()+".fileprovider", image);

        mCM = imageUri.toString();

        return image;
    }



    @Override
    public void onConfigurationChanged(Configuration newConfig){
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (requestCode == FCR) {
            if (null == mUMA) return;
            if (resultCode == Activity.RESULT_OK) {
                Uri[] results = null;
                if (intent == null || intent.getData() == null) {
                    // Capture Photo if no image available
                    if (mCM != null) {
                        results = new Uri[]{Uri.fromFile(new File(mCM))};
                    }
                } else {
                    results = new Uri[]{intent.getData()};
                }
                mUMA.onReceiveValue(results);
            } else {
                mUMA.onReceiveValue(null);
            }
            mUMA = null;
        }
    }



    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }



    public class MyDownloadListener implements DownloadListener {
        private Context context;

        public MyDownloadListener(Context context) {
            this.context = context;
        }

        @Override
        public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
            // Request storage permission using Dexter
            Dexter.withActivity((Activity) context)
                    .withPermissions(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    .withListener(new MultiplePermissionsListener() {
                        @Override
                        public void onPermissionsChecked(MultiplePermissionsReport report) {
                            if (report.areAllPermissionsGranted()) {
                                startDownload(url, userAgent, contentDisposition, mimetype);
                            }
                        }

                        @Override
                        public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                            // Handle permission rationale if needed
                            token.continuePermissionRequest();
                        }
                    })
                    .check();
        }

        private void startDownload(String url, String userAgent, String contentDisposition, String mimetype) {
            // Get the file name from the content disposition
            String fileName = URLUtil.guessFileName(url, contentDisposition, mimetype);


            // Create a DownloadManager request
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setMimeType(mimetype);
            request.addRequestHeader("User-Agent", userAgent);
            request.setDescription("Downloading file");
            request.setTitle(fileName);

            // Set cookies if needed
            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null) {
                request.addRequestHeader("Cookie", cookies);
            }

            // Set the destination path for the downloaded file
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);

            // Set notification visibility to remain visible after download completion
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

            // Enqueue the download
            DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
            if (downloadManager != null) {
                downloadManager.enqueue(request);
            }
        }
    }

}