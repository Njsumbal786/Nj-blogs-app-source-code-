package com.iexpertapp.supelotweb;



public class SmartWebView {


	//Permission variables
	public static final boolean ASWP_JSCRIPT     = true;     //enable JavaScript for webview
	public static final boolean ASWP_FUPLOAD     = true;     //upload file from webview
	public static final boolean ASWP_CAMUPLOAD   = true;     //enable upload from camera for photos
	public static final boolean ASWP_ONLYCAM		 = false;    //incase you want only camera files to upload
	public static final boolean ASWP_MULFILE     = true;    //upload multiple files in webview
	public static final boolean ASWP_LOCATION    = true;     //track GPS locations
	public static final boolean ASWP_RATINGS     = true;     //show ratings dialog; auto configured, edit method get_rating() for customizations
	public static final boolean ASWP_PBAR        = true;    //show progress bar in app
	public static final boolean ASWP_ZOOM        = true;    //zoom control for webpages view
	public static final boolean ASWP_SFORM       = true;    //save form cache and auto-fill information
	public static final boolean ASWP_OFFLINE     = false;    //whether the loading webpages are offline or online
	public static final boolean ASWP_EXTURL      = true;     //open external url with default browser instead of app webview

	//Configuration variables
	public static final String ASWV_URL          = ""; //complete URL of your website or webpage
	public static final String ASWV_F_TYPE       = "images/*";  //to upload any file type using "*/*"; check file type references for more

	//Rating system variables
	public static final int ASWR_DAYS            = 3;        //after how many days of usage would you like to show the dialoge
	public static final int ASWR_TIMES           = 10;       //overall request launch times being ignored
	public static final int ASWR_INTERVAL        = 2;        //reminding users to rate after days interval
}
